import React from 'react';
import { Link } from 'react-router-dom';
import styles from './register.module.css';

function Register() {
    return (
      <div>
        <div className={styles.head}>
            <h1 className={styles.h1}>Computer Security</h1>
        </div>
        <div className={styles.signin}>
            <p className={styles.p_signin}> DROP THE MONEYYY อี๊ๆๆๆๆๆ </p>
        </div>

        <div className={styles.mid}>
        </div>
      </div>
    );
}


export default Register;
  