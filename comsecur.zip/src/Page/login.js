import React from 'react';
import { Link } from 'react-router-dom';
import styles from './login.module.css';

function Login() {
    return (
      <div>
        <div className={styles.head}>
            <h1 className={styles.h1}>Computer Security</h1>
        </div>
        <div className={styles.signin}>
            <p className={styles.p_signin}>SIGN IN</p>
        </div>

        <div className={styles.mid}>
            <div  className={styles.space} />
            <div className={styles.right}>
                <div className={styles.username}>
                    <p className={styles.p_username}>USERNAME:</p>
                </div>
                <div className={styles.box_username}>
                    <input className={styles.ip_username} />
                </div>
                <div className={styles.password}>
                    <p className={styles.p_password}>PASSWORD:</p>
                </div>
                <div className={styles.box_password}>
                    <input className={styles.ip_password} />
                </div>
                <Link to='/forget' className={styles.p_forgot}>FORGOT PASSWORD?</Link>
                <div className={styles.d_signin_btn}>
                    <Link to='/register' className={styles.signin_btn}>SIGN IN</Link>
                </div>
            </div>
        </div>

        <div className={styles.bottom}>
            <p className={styles.p_bottom}>Don’t have an account? <span className={styles.sp_bottom}>Sign up</span>  here</p>
        </div>
      </div>
    );
}


export default Login;
  